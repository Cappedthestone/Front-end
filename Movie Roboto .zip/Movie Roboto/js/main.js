var carts = document.querySelectorAll(".add-cart");
let products = [
    {  
        name: 'Badboy',
        tag: 'badboy',
        price: 5,
        inCart: 0
    },
    {  
        name: 'Bloodshot',
        tag: 'bloodshot',
        price: 10,
        inCart: 0
    },
    {
        
        name: 'Kingsman',
        tag: 'kingsman',
        price: 6,
        inCart: 0
    },
    {
        
        name: 'Money-heist',
        tag: 'money-heist',
        price: 3,
        inCart: 0
    },
    {
        name: 'Security',
        tag: 'security',
        price: 1,
        inCart: 0

    },
    
    {
        
        name: 'Freeguy',
        tag: 'Freeguy',
        price: 3.00,
        inCart: 0
    },
    {
        
        name: 'Jumani',
        tag: 'jumani',
        price: 4,
        inCart: 0
    },
    {
        
        name: 'Uncage',
        tag: 'uncage',
        price: 5,
        inCart: 0
    },
    {
        
        name: 'Police',
        tag: 'police',
        price: 7,
        inCart: 0
    },
    {
        
        name: 'Perfect-date',
        tag: 'perfect-date',
        price: 3,
        inCart: 0
    }
];
for(let i=0; i<carts.length; i++){
    
    carts[i].addEventListener('click', ()=>{
        
        numberOfCarts(products[i]); 
        totalCost(products[i]);
        removeall(products[i]) ; 
         
    })
}

function onloadNumbers(){
    var productsNumber = localStorage.getItem('numberOfCarts');
    if(productsNumber){
        document.querySelector(".nav-item span").textContent = productsNumber;
    }
};

function numberOfCarts(product, action){ 
    let productsNumber = localStorage.getItem('numberOfCarts');
    productsNumber = parseInt(productsNumber);
    let cartItems = localStorage.getItem('productInCart');
    cartItems = JSON.parse(cartItems);

    if( action ) {
        localStorage.setItem("numberOfCarts", productsNumber - 1);
        document.querySelector('.nav-item span').textContent = productsNumber - 1;
    }else if(productsNumber){
       
         localStorage.setItem('numberOfCarts', productsNumber + 1); 
         console.log(productsNumber);
        document.querySelector(".nav-item span").textContent = productsNumber + 1;               
     }else{
         localStorage.setItem('numberOfCarts', 1);
         document.querySelector(".nav-item span").textContent = 1;    
     } 
     setMovies(product);
 }
 
 
 function setMovies(product){ 
    let cartItems = localStorage.getItem('productInCart');
    cartItems = JSON.parse(cartItems);

    if(cartItems != null) {
        let currentProduct = product.tag;
    if(cartItems !=null){
        if(cartItems[currentProduct] ==undefined){
            cartItems = {
                    ...cartItems,
                    [currentProduct]: product
            }

        }
    }
        cartItems[currentProduct].inCart +=1;
    }else{     
        product.inCart = 1;
        cartItems = {
            [product.tag]: product
        }
    }
   localStorage.setItem('productInCart', JSON.stringify(cartItems));
}

function totalCost(product, action){
    let cartCost = localStorage.getItem("totalCost");
    
    if( action) {
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost - product.price);
    }else if(cartCost != null){
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost + product.price);
    }else{
        localStorage.setItem("totalCost", product.price);
    }  
}
 
 function displayCart(){
 let carItems = localStorage.getItem("productInCart");
 carItems = JSON.parse(carItems);
 let cartCost = localStorage.getItem("totalCost");
 cartCost = parseInt(cartCost);
 let moviesContainer = document.querySelector(".products");
 
 if(carItems && moviesContainer){
     moviesContainer.innerHTML ='';
     Object.values(carItems).map(item =>{
         moviesContainer.innerHTML += `
         <br>
         <div class="product-container">
         <div class="product">
         <i class="far fa-times-circle"></i>
         <img src="./images/${item.tag}.jpg">
         <span>${item.name}</span>
         </div>    
         <div class="price"> $${item.price}.00</div>       
         <div class="quantity"> 
         <i class="fas fa-angle-left"></i>
         <span>${item.inCart}</span>
         <i class="fas fa-angle-right"></i>
         </div>
         <div id="total">
         $${item.inCart * item.price}.00
         </div>     
        </div>`
         
     });

     moviesContainer.innerHTML+= `
         <div class="basketTotalContainer">
         <h6 class="basketTotalTitle">Total Price</h6>
         <h4 class="basketTotal">  $${cartCost}.00
        </div>`;
         deleteButtons()
         manageQuantity()
 }
 }
function manageQuantity() {
    let decreaseButtons = document.querySelectorAll('.fa-angle-left');
    let increaseButtons = document.querySelectorAll('.fa-angle-right');
    let currentQuantity = 0;
    let currentProduct = '';
    let cartItems = localStorage.getItem('productInCart');
    cartItems = JSON.parse(cartItems);

    for(let i=0; i < increaseButtons.length; i++) {
        decreaseButtons[i].addEventListener('click', () => {      
            currentQuantity = decreaseButtons[i].parentElement.querySelector('span').textContent;
            currentProduct = decreaseButtons[i].parentElement.previousElementSibling.previousElementSibling.querySelector('span').textContent.toLocaleLowerCase().replace(/ /g,'').trim();
            if( cartItems[currentProduct].inCart > 1 ) {
                cartItems[currentProduct].inCart -= 1;
                numberOfCarts(cartItems[currentProduct], "decrease");
                totalCost(cartItems[currentProduct], "decrease");
                localStorage.setItem('productInCart', JSON.stringify(cartItems));           
                displayCart();       
            }
            
        });
        increaseButtons[i].addEventListener('click', () => {        
            currentQuantity = increaseButtons[i].parentElement.querySelector('span').textContent;
            currentProduct = increaseButtons[i].parentElement.previousElementSibling.previousElementSibling.querySelector('span').textContent.toLocaleLowerCase().replace(/ /g,'').trim();
            cartItems[currentProduct].inCart += 1;     
            numberOfCarts(cartItems[currentProduct]);
            totalCost(cartItems[currentProduct]);
            localStorage.setItem('productInCart', JSON.stringify(cartItems));
            displayCart();
           
        });
    }
}
function deleteButtons() {
    let deleteButtons = document.querySelectorAll('.fa-times-circle');
    let productNumbers = localStorage.getItem('numberOfCarts');
    let cartCost = localStorage.getItem("totalCost");
    let cartItems = localStorage.getItem('productInCart');
    cartItems = JSON.parse(cartItems);
    let productName;

    for(let i=0; i < deleteButtons.length; i++) {
        deleteButtons[i].addEventListener('click', () => {
            productName = deleteButtons[i].parentElement.textContent.toLocaleLowerCase().replace(/ /g,'').trim();
            localStorage.setItem('numberOfCarts', productNumbers - cartItems[productName].inCart);
            localStorage.setItem('totalCost', cartCost - ( cartItems[productName].price * cartItems[productName].inCart));
            delete cartItems[productName];
            localStorage.setItem('productInCart', JSON.stringify(cartItems));
            location.reload();
            displayCart();
            onLoadCartNumbers();
            
        }) 
    }
    
}


onloadNumbers();
displayCart();



var cardholder = document.querySelector("#holder");
var cardnumber = document.querySelector("#cardnum");
var expireDate = document.querySelector("#exdate");
var CVV = document.querySelector("#cvv");

var payNow = document.querySelector("#paymnt");

payNow.addEventListener('click', ()=>{
    if(cardholder.value ==""){
        alert("Please Enter your Card Name");
        location.reload();
    }else  if(cardnumber.value ==""){
        alert("Please Enter your Card Number");
        location.reload();
    }else  if(expireDate.value ==""){
        alert("Please Enter your Expire Date");
        location.reload();
    }else  if(CVV.value ==""){
        alert("Please Enter your Card CVV");
         location.reload();
    }else if(localStorage.getItem('numberOfCarts') == null){
        alert("Add Items in the Cart!!");
    }else{
            alert("Payment Processed. Thank you.");  
            localStorage.removeItem('numberOfCarts');
            localStorage.removeItem('productInCart');
            localStorage.removeItem('totalCost');
            location.reload();    
    } 
});

var card_num = document.querySelector("#cardnum");

card_num.addEventListener('keyup', (e)=>{
    var num = e.target.value;
    console.log(num);
    if(num[0] ==4 || num[0]==5){     
    }else if (num == undefined){  
}else{
        alert("Please write valid Card number");
        location.reload();
    }
    
})




