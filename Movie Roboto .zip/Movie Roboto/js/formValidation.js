
 var val, i, img, input, ol, li, name;
var search = document.querySelector(".form-control");
img = document.querySelectorAll("#image");



search.addEventListener('keyup', (e)=>{
    input =e.target.value.toUpperCase();
    
    for(var j=0; j<img.length; j++){
      ol = img[j].document.querySelector("#name");
      console.log(ol);
    if(ol[j].innerHTML.toUpperCase().indexOf(input) >-1){
        ol[j].style.display ="";
       img[j].style.display = "flex";
    }else{
        ol[j].style.display ="none";
    }
    }
   /**  
    * 
    for(var j=0; j<img.length; j++){
      ol = img[j].document.querySelector("#name");
      console.log(ol);
    if(ol[j].innerHTML.toUpperCase().indexOf(input) >-1){
        ol[j].style.display ="";
       img[j].style.display = "flex";
    }else{
        ol[j].style.display ="none";
    }
    }
    * 
    * 
    * 
    * 
    * 
    * 
    * 
    * */
})



