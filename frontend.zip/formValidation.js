
 var val, i, img, input, ol;
var search = document.querySelector(".form-control");
img = document.querySelectorAll("#image");



search.addEventListener('keyup', (e)=>{
    input =e.target.value.toUpperCase();
   
  for(i=0; i<img.length; i++){
    name = img[i].document.querySelector("#name");
    console.log(img[i].querySelector("#name"));
    
}
   /**  
    * 
    for(var j=0; j<img.length; j++){
      ol = img[j].document.querySelector("#name");
      console.log(ol);
    if(ol[j].innerHTML.toUpperCase().indexOf(input) >-1){
        ol[j].style.display ="";
       img[j].style.display = "flex";
    }else{
        ol[j].style.display ="none";
    }
    }
    * 
    * 
    * 
    * 
    * 
    * 
    * 
    * for(i=0; i<img.length; i++){
        name = img[i].document.getElementById("name");
       
        if(name[0].innerHTML.toUpperCase().indexOf(input) >-1){
            console.log(name); 
          img[i].style.display ="flex";
        }else{
         img[i].style.display ="none";
        }
      }*/
})



