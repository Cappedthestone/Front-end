var carts = document.querySelectorAll(".add-cart");


let products = [
    {  
        name: 'Bad Boys',
        tag: 'badboy',
        price: 5,
        inCart: 0
    },
    {  
        name: 'Bloodshot',
        tag: 'bloodshot',
        price: 10,
        inCart: 0
    },
    {
        
        name: 'Kingsman',
        tag: 'kingsman',
        price: 6,
        inCart: 0
    },
    {
        
        name: 'Money Heist',
        tag: 'money-heist',
        price: 3,
        inCart: 0
    },
    {
        name: 'Security',
        tag: 'Security',
        price: 1,
        inCart: 0

    },
    
    {
        
        name: 'Free Guy',
        tag: 'Freeguy',
        price: 3.00,
        inCart: 0
    },
    {
        
        name: 'Jumani',
        tag: 'Jumani',
        price: 4,
        inCart: 0
    },
    {
        
        name: 'Uncaged',
        tag: 'uncage',
        price: 5,
        inCart: 0
    },
    {
        
        name: 'Sooryavanshi',
        tag: 'police',
        price: 7,
        inCart: 0
    },
    {
        
        name: 'Perfect Date',
        tag: 'perfect-date',
        price: 3,
        inCart: 0
    }
];


for(let i=0; i<carts.length; i++){
    
    carts[i].addEventListener('click', ()=>{
        
        numberOfCarts(products[i]); 
        totalCost(products[i]);
        removeall(products[i]) ; 
         
    })
}



function onloadNumbers(){
    var productsNumber = localStorage.getItem('numberOfCarts');
    if(productsNumber){
        document.querySelector(".nav-item span").textContent = productsNumber;
    }
};


function numberOfCarts(product){ 
   let productsNumber = localStorage.getItem('numberOfCarts');
   productsNumber = parseInt(productsNumber);

    if(isNaN(productsNumber) ){
        localStorage.setItem('numberOfCarts', 1); 
       document.querySelector(".nav-item span").textContent = 1;               
    }else{
        localStorage.setItem('numberOfCarts', productsNumber+1);
        document.querySelector(".nav-item span").textContent = productsNumber+ 1;    
    } 
    setMovies(product);
}


function setMovies(product){ 
    let cartItems = localStorage.getItem('productInCart');
    cartItems = JSON.parse(cartItems);

    if(cartItems !=null){
        if(cartItems[product.tag] ==undefined){
            cartItems = {
                    ...cartItems,
                    [product.tag]: product
            }

        }
        cartItems[product.tag].inCart +=1;
    }else{     
        product.inCart = 1;
        cartItems = {
            [product.tag]: product
        }
    }
   localStorage.setItem('productInCart', JSON.stringify(cartItems));
}

function totalCost(product){
    let cartCost = localStorage.getItem("totalCost");
    
    if(cartCost != null){
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost + product.price);
    }else{
        localStorage.setItem("totalCost", product.price);
    }  
}

function displayCart(){
let carItems = localStorage.getItem("productInCart");
carItems = JSON.parse(carItems);

let moviesContainer = document.querySelector(".products");
let cartCost = localStorage.getItem("totalCost");


if(carItems && moviesContainer){
    moviesContainer.innerHTML ='';
    Object.values(carItems).map(item =>{
        moviesContainer.innerHTML += `
        <br>

        <div class="product-container">
        <div class="product">
        <i class="fas fa-video"></i>
        <img src="./images/${item.tag}.jpg">
        <span>${item.name}</span>
        </div>
        
        <div class="price"> $${item.price}.00</div>
        
        <div class="quantity"> 
        <i class="fas fa-angle-left"></i>
        <span>${item.inCart}</span>
        <i class="fas fa-angle-right"></i>
        </div>

        <div id="total">
        $${item.inCart * item.price}.00
        </div>
       
</div>`
        
    });
    moviesContainer.innerHTML+= `
        <div class="basketTotalContainer">
        <h6 class="basketTotalTitle">Total Price</h6>
        <h4 class="basketTotal">  $${cartCost}.00
            </div>`;
   
}
}

onloadNumbers();
displayCart();



var cardholder = document.querySelector("#holder");
var cardnumber = document.querySelector("#cardnum");
var expireDate = document.querySelector("#exdate");
var CVV = document.querySelector("#cvv");

var payNow = document.querySelector("#paymnt");

payNow.addEventListener('click', ()=>{
    if(cardholder.value ==""){
        alert("Please Enter your card Name");
        location.reload();
    }else  if(cardnumber.value ==""){
        alert("Please Enter your Card Number");
        location.reload();
    }else  if(expireDate.value ==""){
        alert("Please Enter your Expire Date");
        location.reload();
    }else  if(CVV.value ==""){
        alert("Please Enter your card CVV");
         location.reload();
    }else if(localStorage.getItem('numberOfCarts') == null){
        alert("Add Items in the Cart!!");
    }else{
            alert("Payment Processed. Thanks you");  
            localStorage.removeItem('numberOfCarts');
            localStorage.removeItem('productInCart');
            localStorage.removeItem('totalCost');
            location.reload();    
    } 
});

var deletebutton = document.querySelector(".remov");


deletebutton.addEventListener('click', ()=>{
    localStorage.removeItem('numberOfCarts');
    localStorage.removeItem('productInCart');
    localStorage.removeItem('totalCost'); 
    location.reload();
    
})







